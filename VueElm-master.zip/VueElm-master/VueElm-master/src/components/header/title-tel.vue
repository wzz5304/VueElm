<template>
  <div class="title">
    <div class="line"></div>
    <div class="text">优惠信息</div>
    <div class="line"></div>
  </div>
  
</template>

<script>
 export default {};
</script>

<style lang="stylus" rel="stylesheet/stylus">
.title 
  display:flex
  width:80%
  margin:12px auto 24px auto
  .line
    flex:1
    position:relative
    border:1px solid rgba(255,255,255,0.2)
    height:0px
  .text
    font-size:14px
    padding:0 12px
    margin-top:-6px

</style>
