<template>
 <div class="split-content">
 	
 </div>
</template>

<script>
   export default{};
</script>

<style lang="stylus" rel="stylesheet/stylus">
@import "../../common/stylus/minxin.styl" 
    .split-content
    	width:100%
    	height:16px
    	background:#f3f5f7
    	border-top:1px solid rgba(7,17,27,0.1)
    	border-bottom:1px solid rgba(7,17,27,0.1)
</style>
